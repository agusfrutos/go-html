# React benchmark

## Tasks

### install

```
npm i
```

### build

```sh
npm run build
```

### run

requires: build

```sh
npm start
```

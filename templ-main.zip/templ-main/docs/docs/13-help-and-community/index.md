# Getting help

For help from the community, talking about new ideas, and general discussion:

## Slack

Use the #templ channel in the Gopher Slack community.

https://invite.slack.golangbridge.org/

## Github Discussion

https://github.com/a-h/templ/discussions
